﻿/// <summary>
/// Class will contain entities for contact
/// </summary>
namespace ContactsRestWebAPI.Models
{
    public class contact
    {
        public int contactId { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public string email { get; set; }
        public string phonenumber { get; set; }
        public string status { get; set; }

    }
}